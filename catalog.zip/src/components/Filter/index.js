// import React, { useEffect, useState } from "react";
// import axios from "axios";

// import MovieComponent from "../Movie";

// const Filter = (movie, setMovie) => {
//   // let movies = Array.from(movie.Search);
//   const [term, setTerm] = useState("");
//   const [filterMovies, setFilterMovies] = useState([]);

//   const search = (e) => {
//     if (term === "") {
//       setFilterMovies(movie);
//       return;
//     }

//     const filtered =
//       movie &&
//       movie.filter((item) => {
//         return item.Title.toLowerCase().startsWith(e.toLowerCase());
//       });
//     setFilterMovies(filtered);
//   };

//   useEffect(() => {
//     const fetchData = async () => {
//       const result = await axios.get(
//         `https://www.omdbapi.com/?i=tt3896198&apikey=8523cbb8&s=Batman&page=2`
//       );
//       setMovie(result.data);
//       setFilterMovies(result.data);
//     };
//     fetchData();
//   }, []);

//   const template = filterMovies.map((item) => (
//     <MovieComponent key={item.imdbID} item={item} setMovie={setFilterMovies} />
//   ));

//   return (
//     <div className="page">
//       <div className="search">
//         <input
//           className="search__movies"
//           type="text"
//           placeholder="Search"
//           value={term}
//           onChange={(event) => setTerm(event.target.value)}
//         ></input>
//         <button className="search__button" onClick={() => search()}>
//           Click
//         </button>
//       </div>

//       {movie && template}
//     </div>
//   );
// };

// export default Filter;
