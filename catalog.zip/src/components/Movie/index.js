import { useState, useEffect } from "react";
import axios from "axios";

const MovieComponent = () => {
  const [movie, setMovie] = useState({});
  let arrMovie;

  useEffect(() => {
    const fetchData = async () => {
      const result = await axios.get(
        `https://www.omdbapi.com/?i=tt3896198&apikey=8523cbb8&s=Batman&page=2`
      );
      setMovie(result.data);
    };
    console.log(movie.Search)
    fetchData();
    
  }, []);

  return (
    <div className="movies">
      <ul className="movies-list">
        {Array.from(movie.Search).map((movie) => (
          <li key={movie.imdbID} className="movie">
            <img src={movie.Poster} className="img" />
            <p className="movie-name">{movie.Title}</p>
            <p className="movie-year">{movie.Year}</p>
            <p className="movie-type">{movie.Type}</p>
            <p className="movie-imdbID">{movie.imdbID}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MovieComponent;
